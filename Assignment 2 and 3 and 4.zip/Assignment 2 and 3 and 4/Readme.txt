------------------------------------README--------------------------------------------------------------------
->1. index.html is main file 
->2. All css include in the style.css file. This is the external css file
->3. Image source: https://cdn.fstoppers.com/styles/full/s3/media/2019/12/04/nando-jpeg-quality-001.jpg

--------------------------Instruction of Run the Project---------------------------------------------
1. Download the zip file 
2. Unzip the file 
3. Click the index file to see the website design 
4. All media queries written on the bottom of the css file  